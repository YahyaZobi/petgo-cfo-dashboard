
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/lib/boardpack.mjs
import { getStore } from "@netlify/blobs";
import { Resend } from "resend";
var STORE_NAME = "boardpack";
var LATEST_KEY = "latest";
var RECIPIENTS_KEY = "recipients";
var FROM = process.env.BOARDPACK_FROM || "PETGO Vantage <onboarding@resend.dev>";
var MAX_HTML = 380 * 1024;
function store() {
  return getStore(STORE_NAME);
}
async function saveLatest(obj) {
  await store().setJSON(LATEST_KEY, obj);
}
async function getRecipients() {
  try {
    return await store().get(RECIPIENTS_KEY, { type: "json" }) || {};
  } catch {
    return {};
  }
}
async function saveRecipients(map) {
  await store().setJSON(RECIPIENTS_KEY, map);
}
function validEmail(e) {
  return typeof e === "string" && /^[^@\s]+@petgo\.ly$/i.test(e.trim());
}
function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
}

// netlify/functions/publish-boardpack.mjs
var publish_boardpack_default = async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid JSON" }, 400);
  }
  const { html, dataAsOf, subscriber } = body || {};
  let storedArtifact = false, storedSubscriber = false;
  if (typeof html === "string" && html.length > 0) {
    if (html.length > MAX_HTML) return json({ error: "Snapshot too large" }, 413);
    await saveLatest({ html, dataAsOf: dataAsOf || (/* @__PURE__ */ new Date()).toISOString(), updatedAt: (/* @__PURE__ */ new Date()).toISOString() });
    storedArtifact = true;
  }
  if (subscriber && typeof subscriber.email === "string") {
    if (!validEmail(subscriber.email)) return json({ error: "Recipient must be a @petgo.ly address" }, 400);
    const email = subscriber.email.trim().toLowerCase();
    const cadence = subscriber.cadence || "off";
    const recips = await getRecipients();
    if (cadence === "off") {
      delete recips[email];
    } else {
      recips[email] = { name: String(subscriber.name || "").slice(0, 80), cadence, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    }
    await saveRecipients(recips);
    storedSubscriber = true;
  }
  return json({ ok: true, storedArtifact, storedSubscriber });
};
export {
  publish_boardpack_default as default
};
