
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/lib/boardpack.mjs
import { getStore } from "@netlify/blobs";
import { Resend } from "resend";
var STORE_NAME = "boardpack";
var LATEST_KEY = "latest";
var RECIPIENTS_KEY = "recipients";
var FROM = process.env.BOARDPACK_FROM || "PETGO Vantage <onboarding@resend.dev>";
var MAX_HTML = 380 * 1024;
function store() {
  return getStore(STORE_NAME);
}
async function getLatest() {
  try {
    return await store().get(LATEST_KEY, { type: "json" });
  } catch {
    return null;
  }
}
async function getRecipients() {
  try {
    return await store().get(RECIPIENTS_KEY, { type: "json" }) || {};
  } catch {
    return {};
  }
}
async function sendEmail({ to, subject, html }) {
  const key = process.env.RESEND_API_KEY;
  if (!key) throw new Error("RESEND_API_KEY is not configured on this site");
  const resend = new Resend(key);
  const { data, error } = await resend.emails.send({ from: FROM, to, subject, html });
  if (error) throw new Error(error.message || "Resend send failed");
  return data;
}
function subjectFor(dataAsOf) {
  let d = "latest";
  try {
    d = new Date(dataAsOf || Date.now()).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  } catch {
  }
  return `PETGO Board Pack \u2014 Finance Overview (${d})`;
}

// netlify/functions/send-boardpack.mjs
var send_boardpack_default = async () => {
  const latest = await getLatest();
  if (!latest || !latest.html) {
    console.log("[boardpack] no snapshot published yet \u2014 nothing to send");
    return;
  }
  const recips = await getRecipients();
  const emails = Object.keys(recips).filter((e) => recips[e] && recips[e].cadence && recips[e].cadence !== "off");
  if (!emails.length) {
    console.log("[boardpack] no opted-in recipients");
    return;
  }
  const subject = subjectFor(latest.dataAsOf);
  let sent = 0;
  for (const to of emails) {
    try {
      await sendEmail({ to, subject, html: latest.html });
      sent++;
    } catch (e) {
      console.error("[boardpack] send failed for", to, "-", e.message);
    }
  }
  console.log(`[boardpack] weekly send complete: ${sent}/${emails.length} delivered (snapshot ${latest.dataAsOf})`);
};
var config = { schedule: "0 7 * * 0" };
export {
  config,
  send_boardpack_default as default
};
