
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/lib/boardpack.mjs
import { getStore } from "@netlify/blobs";
import { Resend } from "resend";
var STORE_NAME = "boardpack";
var LATEST_KEY = "latest";
var FROM = process.env.BOARDPACK_FROM || "PETGO Vantage <onboarding@resend.dev>";
var MAX_HTML = 380 * 1024;
function store() {
  return getStore(STORE_NAME);
}
async function getLatest() {
  try {
    return await store().get(LATEST_KEY, { type: "json" });
  } catch {
    return null;
  }
}
function validEmail(e) {
  return typeof e === "string" && /^[^@\s]+@petgo\.ly$/i.test(e.trim());
}
async function sendEmail({ to, subject, html }) {
  const key = process.env.RESEND_API_KEY;
  if (!key) throw new Error("RESEND_API_KEY is not configured on this site");
  const resend = new Resend(key);
  const { data, error } = await resend.emails.send({ from: FROM, to, subject, html });
  if (error) throw new Error(error.message || "Resend send failed");
  return data;
}
function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
}

// netlify/functions/send-boardpack-test.mjs
var send_boardpack_test_default = async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid JSON" }, 400);
  }
  const to = String(body && body.to || "").trim().toLowerCase();
  if (!validEmail(to)) return json({ error: "Recipient must be a @petgo.ly address" }, 400);
  let html = typeof body.html === "string" && body.html.length > 0 && body.html.length <= MAX_HTML ? body.html : null;
  if (!html) {
    const latest = await getLatest();
    html = latest && latest.html;
  }
  if (!html) return json({ error: "No Board Pack available yet \u2014 open the Dashboard first" }, 400);
  try {
    await sendEmail({ to, subject: "PETGO Board Pack \u2014 test send", html });
  } catch (e) {
    return json({ error: e.message }, 500);
  }
  return json({ ok: true, sentTo: to });
};
export {
  send_boardpack_test_default as default
};
